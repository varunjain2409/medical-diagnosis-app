import os
import math
import json
import urllib.request
import urllib.parse

GOOGLE_API_KEY = os.getenv("GOOGLE_PLACES_API_KEY", "")

DISEASE_TO_SPECIALIST = {
    "Common Cold":              ["General Physician", "ENT Specialist"],
    "Influenza (Flu)":          ["General Physician", "Pulmonologist"],
    "COVID-19":                 ["General Physician", "Pulmonologist"],
    "Typhoid Fever":            ["General Physician", "Gastroenterologist"],
    "Malaria":                  ["General Physician", "Infectious Disease Specialist"],
    "Dengue Fever":             ["General Physician", "Infectious Disease Specialist"],
    "Gastroenteritis":          ["Gastroenterologist", "General Physician"],
    "Pneumonia":                ["Pulmonologist", "General Physician"],
    "Diabetes (Type 2)":        ["Endocrinologist", "Diabetologist"],
    "Jaundice / Hepatitis":     ["Hepatologist", "Gastroenterologist"],
    "Hypertension":             ["Cardiologist", "General Physician"],
    "Allergic Rhinitis":        ["Allergist", "ENT Specialist"],
    "Anxiety / Panic Disorder": ["Psychiatrist", "General Physician"],
    "GERD / Acid Reflux":       ["Gastroenterologist", "General Physician"],
    "Eczema":                   ["Dermatologist", "General Physician"],
    "Psoriasis":                ["Dermatologist"],
    "Conjunctivitis (Pink Eye)":["Ophthalmologist", "General Physician"],
    "Tonsillitis":              ["ENT Specialist", "General Physician"],
    "Visual Assessment":        ["Dermatologist", "General Physician"],
}

SPECIALIST_KEYWORDS = {
    "General Physician":    "general physician doctor clinic",
    "Pulmonologist":        "pulmonologist lung specialist",
    "Gastroenterologist":   "gastroenterologist stomach specialist",
    "Dermatologist":        "dermatologist skin specialist",
    "Cardiologist":         "cardiologist heart specialist",
    "Endocrinologist":      "endocrinologist diabetes specialist",
    "Diabetologist":        "diabetologist doctor",
    "ENT Specialist":       "ENT ear nose throat specialist",
    "Hepatologist":         "hepatologist liver specialist",
    "Allergist":            "allergist immunologist",
    "Psychiatrist":         "psychiatrist mental health",
    "Ophthalmologist":      "ophthalmologist eye specialist",
    "Infectious Disease Specialist": "infectious disease specialist",
}

def haversine_distance(lat1, lon1, lat2, lon2):
    R = 6371
    d_lat = math.radians(lat2 - lat1)
    d_lon = math.radians(lon2 - lon1)
    a = (math.sin(d_lat/2)**2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(d_lon/2)**2)
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

def get_location_name(lat, lng):
    try:
        url = f"https://nominatim.openstreetmap.org/reverse?lat={lat}&lon={lng}&format=json"
        req = urllib.request.Request(url, headers={"User-Agent": "MediAI/1.0"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode())
        addr = data.get("address", {})
        parts = [addr.get("suburb"), addr.get("city") or addr.get("town"),
                 addr.get("state"), addr.get("country")]
        return ", ".join(p for p in parts if p) or "Your Location"
    except Exception as e:
        print(f"[Geocode] {e}")
        return "Your Location"

def fetch_doctors_google(lat, lng, specialist, radius_km=50):
    if not GOOGLE_API_KEY:
        return []
    keyword = SPECIALIST_KEYWORDS.get(specialist, "doctor clinic hospital")
    radius_m = min(radius_km * 1000, 50000)
    params = urllib.parse.urlencode({
        "location": f"{lat},{lng}",
        "radius": radius_m,
        "keyword": keyword,
        "type": "doctor|hospital|health",
        "key": GOOGLE_API_KEY
    })
    try:
        url = f"https://maps.googleapis.com/maps/api/place/nearbysearch/json?{params}"
        req = urllib.request.Request(url, headers={"User-Agent": "MediAI/1.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
        results = []
        for place in data.get("results", [])[:12]:
            p_lat = place["geometry"]["location"]["lat"]
            p_lng = place["geometry"]["location"]["lng"]
            dist = haversine_distance(lat, lng, p_lat, p_lng)
            if dist > radius_km:
                continue
            opening = place.get("opening_hours", {})
            is_open = opening.get("open_now", None)
            photo_url = None
            if place.get("photos"):
                ref = place["photos"][0]["photo_reference"]
                photo_url = (f"https://maps.googleapis.com/maps/api/place/photo"
                             f"?maxwidth=300&photo_reference={ref}&key={GOOGLE_API_KEY}")
            results.append({
                "name": place.get("name", "Unknown"),
                "address": place.get("vicinity", ""),
                "rating": place.get("rating", 0),
                "total_ratings": place.get("user_ratings_total", 0),
                "distance_km": round(dist, 1),
                "specialist": specialist,
                "is_open": is_open,
                "open_status": "Open Now" if is_open else ("Closed" if is_open is False else "N/A"),
                "photo_url": photo_url,
                "phone": "",
                "maps_url": f"https://www.google.com/maps/place/?q=place_id:{place.get('place_id','')}",
                "lat": p_lat, "lng": p_lng,
                "source": "Google Places",
                "place_id": place.get("place_id", ""),
            })
        results.sort(key=lambda x: x["distance_km"])
        return results
    except Exception as e:
        print(f"[Google] {e}")
        return []

def fetch_doctors_osm(lat, lng, specialist, radius_km=50):
    radius_m = radius_km * 1000
    query = f"""
    [out:json][timeout:25];
    (
      node["amenity"="hospital"](around:{radius_m},{lat},{lng});
      node["amenity"="clinic"](around:{radius_m},{lat},{lng});
      node["amenity"="doctors"](around:{radius_m},{lat},{lng});
      node["healthcare"="doctor"](around:{radius_m},{lat},{lng});
      node["healthcare"="hospital"](around:{radius_m},{lat},{lng});
      way["amenity"="hospital"](around:{radius_m},{lat},{lng});
      way["amenity"="clinic"](around:{radius_m},{lat},{lng});
    );
    out center 20;
    """
    try:
        encoded = urllib.parse.urlencode({"data": query}).encode()
        req = urllib.request.Request(
            "https://overpass-api.de/api/interpreter",
            data=encoded,
            headers={"User-Agent": "MediAI/1.0",
                     "Content-Type": "application/x-www-form-urlencoded"}
        )
        with urllib.request.urlopen(req, timeout=25) as resp:
            data = json.loads(resp.read().decode())
        results = []
        for el in data.get("elements", []):
            tags = el.get("tags", {})
            name = tags.get("name") or tags.get("name:en")
            if not name:
                continue
            if el["type"] == "node":
                p_lat, p_lng = el.get("lat", 0), el.get("lon", 0)
            else:
                center = el.get("center", {})
                p_lat, p_lng = center.get("lat", 0), center.get("lon", 0)
            if not p_lat or not p_lng:
                continue
            dist = haversine_distance(lat, lng, p_lat, p_lng)
            if dist > radius_km:
                continue
            addr_parts = [tags.get("addr:housenumber"), tags.get("addr:street"),
                          tags.get("addr:suburb"), tags.get("addr:city")]
            address = ", ".join(p for p in addr_parts if p) or tags.get("addr:full", "")
            phone = tags.get("phone") or tags.get("contact:phone", "")
            website = tags.get("website") or tags.get("contact:website", "")
            search_q = urllib.parse.quote(f"{name} {address}".strip())
            results.append({
                "name": name,
                "address": address or "Address not listed",
                "rating": 0,
                "total_ratings": 0,
                "distance_km": round(dist, 1),
                "specialist": specialist,
                "is_open": None,
                "open_status": tags.get("opening_hours", "Hours not listed"),
                "photo_url": None,
                "phone": phone,
                "website": website,
                "maps_url": f"https://www.google.com/maps/search/?api=1&query={search_q}",
                "lat": p_lat, "lng": p_lng,
                "source": "OpenStreetMap",
                "place_id": str(el.get("id", "")),
            })
        results.sort(key=lambda x: x["distance_km"])
        return results[:12]
    except Exception as e:
        print(f"[OSM] {e}")
        return []

def find_nearby_doctors(lat, lng, disease=None, specialists=None, radius_km=50):
    if not specialists:
        specialists = DISEASE_TO_SPECIALIST.get(disease, ["General Physician"])
    all_results = []
    seen = set()
    for spec in specialists[:2]:
        docs = fetch_doctors_google(lat, lng, spec, radius_km) if GOOGLE_API_KEY \
               else fetch_doctors_osm(lat, lng, spec, radius_km)
        for d in docs:
            pid = d.get("place_id") or d["name"]
            if pid not in seen:
                seen.add(pid)
                all_results.append(d)
    all_results.sort(key=lambda x: x["distance_km"])
    location_name = get_location_name(lat, lng)
    return {
        "doctors": all_results[:12],
        "total_found": len(all_results),
        "specialists_searched": specialists,
        "radius_km": radius_km,
        "location_name": location_name,
        "source": "Google Places" if GOOGLE_API_KEY else "OpenStreetMap",
        "lat": lat,
        "lng": lng,
    }

def get_specialists_for_disease(disease):
    return DISEASE_TO_SPECIALIST.get(disease, ["General Physician"])
