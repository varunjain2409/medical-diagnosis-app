import os
import re
import secrets
from datetime import timedelta
from functools import wraps
from collections import defaultdict
from time import time as _time

from flask import (Flask, render_template, request, redirect, url_for,
                   session, flash, jsonify, abort)
from werkzeug.utils import secure_filename

from visual_assessment import analyze_image_with_ai, build_visual_report, VISUAL_ASSESSMENT_GUIDE
from doctor_finder import find_nearby_doctors, get_specialists_for_disease, DISEASE_TO_SPECIALIST
from database import (
    save_prescription, get_prescriptions, get_prescription_by_id,
    init_db, register_user, login_user, get_patient_profile,
    update_patient_profile, save_diagnosis, get_patient_history,
    get_diagnosis_by_id, get_diagnosis_for_user, get_all_diagnoses_admin,
    get_hospital_profile, update_hospital_profile,
    add_doctor, get_doctors_for_hospital, get_doctor_for_hospital,
    update_doctor, toggle_doctor_availability, delete_doctor,
    admin_get_stats, admin_get_all_patients, admin_get_all_hospitals,
    admin_get_all_diagnoses, admin_get_all_prescriptions,
    admin_get_all_hospital_doctors, admin_delete_user,
    admin_delete_diagnosis, admin_delete_prescription,
    admin_delete_hospital_doctor, admin_reset_password,
    admin_toggle_user_role, admin_get_activity_log,
    admin_get_user_by_id, admin_get_all_users,
)
from ml_model import predict_disease, normalize_symptoms, get_all_symptoms, train_model
from ai_report import generate_ai_report
from prescription_analyzer import analyze_prescription_with_ai, build_prescription_report, extract_medicines_from_text

# ─── APP CONFIG ───────────────────────────────────────────────────────────────

app = Flask(__name__)

# Strong random secret key – regenerated each start (rotate via env var in production)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", secrets.token_hex(32))

app.config.update(
    UPLOAD_FOLDER=os.path.join("static", "uploads"),
    MAX_CONTENT_LENGTH=16 * 1024 * 1024,          # 16 MB upload cap
    SESSION_COOKIE_HTTPONLY=True,                  # JS can't read session cookie
    SESSION_COOKIE_SAMESITE="Lax",                 # CSRF mitigation
    SESSION_COOKIE_SECURE=False,                   # Set True in HTTPS production
    PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
)

ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png", "gif", "webp"}
def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

# ─── SIMPLE IN-MEMORY RATE LIMITER ────────────────────────────────────────────

_login_attempts: dict = defaultdict(list)   # ip -> [timestamp, ...]
LOGIN_MAX   = 5     # attempts
LOGIN_WINDOW = 300  # seconds (5 min)

def check_rate_limit(ip: str) -> bool:
    """Return True if request is allowed, False if blocked."""
    now = _time()
    _login_attempts[ip] = [t for t in _login_attempts[ip] if now - t < LOGIN_WINDOW]
    if len(_login_attempts[ip]) >= LOGIN_MAX:
        return False
    _login_attempts[ip].append(now)
    return True

def reset_rate_limit(ip: str):
    _login_attempts.pop(ip, None)

# ─── CSRF TOKEN HELPER ────────────────────────────────────────────────────────

def generate_csrf():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_hex(24)
    return session["csrf_token"]

def validate_csrf():
    token = request.form.get("csrf_token") or request.headers.get("X-CSRFToken")
    if not token or token != session.get("csrf_token"):
        abort(400, "CSRF validation failed. Please refresh and try again.")

app.jinja_env.globals["csrf_token"] = generate_csrf  # available in every template

# ─── DECORATORS ──────────────────────────────────────────────────────────────

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated

def patient_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get("role") not in ("patient", "admin"):
            flash("This area is for patients only.", "warning")
            return redirect(url_for("hospital_dashboard"))
        return f(*args, **kwargs)
    return decorated

def hospital_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get("role") != "hospital":
            flash("This area is for hospitals only.", "warning")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        # Must be logged in
        if "user_id" not in session:
            flash("Please log in.", "warning")
            return redirect(url_for("login"))
        # Must have admin role
        if session.get("role") != "admin":
            # Log unauthorized attempt
            try:
                admin_log_to_db(
                    session.get("username","unknown"),
                    "UNAUTHORIZED_ACCESS",
                    f"Tried to access {request.path}",
                    request.remote_addr or "unknown"
                )
            except:
                pass
            flash("⛔ Admin access required. This attempt has been logged.", "danger")
            return redirect(url_for("dashboard"))
        # Must have completed admin PIN verification
        if not session.get("admin_verified"):
            return redirect(url_for("admin_verify"))
        return f(*args, **kwargs)
    return decorated

@app.route("/admin/verify", methods=["GET", "POST"])
@login_required
def admin_verify():
    """Second-factor PIN check before accessing admin panel."""
    if session.get("role") != "admin":
        flash("Not authorized.", "danger")
        return redirect(url_for("dashboard"))
    if session.get("admin_verified"):
        return redirect(url_for("admin"))

    ADMIN_PIN = os.environ.get("ADMIN_PIN", "1234")  # Change in production!

    if request.method == "POST":
        entered = request.form.get("pin", "").strip()
        ip = request.remote_addr or "unknown"
        if entered == ADMIN_PIN:
            session["admin_verified"] = True
            session.permanent = True
            try:
                admin_log_to_db(session.get("username","?"), "ADMIN_LOGIN", "PIN verified", ip)
            except: pass
            flash("✅ Admin access granted.", "success")
            return redirect(url_for("admin"))
        else:
            try:
                admin_log_to_db(session.get("username","?"), "WRONG_PIN", f"Wrong PIN from IP:{ip}", ip)
            except: pass
            flash("❌ Wrong PIN. Attempt logged.", "danger")
    return render_template("admin_verify.html")

# ─── INPUT HELPERS ────────────────────────────────────────────────────────────

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

def clean(val, max_len=200):
    return (val or "").strip()[:max_len]

def valid_email(email):
    return bool(_EMAIL_RE.match(email))

# ─── AUTH ROUTES ─────────────────────────────────────────────────────────────

@app.route("/")
def index():
    if "user_id" in session:
        if session.get("role") == "hospital":
            return redirect(url_for("hospital_dashboard"))
        return redirect(url_for("dashboard"))
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        validate_csrf()
        role          = clean(request.form.get("role", "patient"))
        if role not in ("patient", "hospital"):
            role = "patient"

        username      = clean(request.form.get("username", ""))
        password      = request.form.get("password", "")
        confirm_pw    = request.form.get("confirm_password", "")
        full_name     = clean(request.form.get("full_name", ""))
        email         = clean(request.form.get("email", "")).lower()

        # Hospital-specific fields
        hospital_name    = clean(request.form.get("hospital_name", ""))
        hospital_address = clean(request.form.get("hospital_address", ""))
        hospital_contact = clean(request.form.get("hospital_contact", ""))

        # ── Validation ──────────────────────────────────────────────────────
        errors = []
        if not all([username, password, full_name, email]):
            errors.append("All required fields must be filled in.")
        if not valid_email(email):
            errors.append("Enter a valid email address.")
        if len(password) < 8:
            errors.append("Password must be at least 8 characters.")
        if password != confirm_pw:
            errors.append("Passwords do not match.")
        if not re.match(r"^[A-Za-z0-9_]{3,30}$", username):
            errors.append("Username must be 3–30 alphanumeric characters (or _).")
        if role == "hospital" and not hospital_name:
            errors.append("Hospital name is required.")
        for err in errors:
            flash(err, "danger")
        if errors:
            return render_template("register.html")

        success, msg = register_user(
            username, password, full_name, email, role,
            hospital_name=hospital_name if role == "hospital" else None,
            hospital_address=hospital_address if role == "hospital" else None,
            hospital_contact=hospital_contact if role == "hospital" else None,
        )
        if success:
            flash(msg + " Please log in.", "success")
            return redirect(url_for("login"))
        else:
            flash(msg, "danger")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        validate_csrf()
        ip       = request.remote_addr
        username = clean(request.form.get("username", ""))
        password = request.form.get("password", "")

        if not check_rate_limit(ip):
            flash("Too many failed login attempts. Please wait 5 minutes.", "danger")
            return render_template("login.html")

        user = login_user(username, password)
        if user:
            reset_rate_limit(ip)
            session.clear()
            session.permanent = True
            session["user_id"]   = user["id"]
            session["username"]  = user["username"]
            session["full_name"] = user["full_name"]
            session["role"]      = user["role"]
            generate_csrf()   # fresh CSRF token after login
            flash(f"Welcome back, {user['full_name']}!", "success")
            if user["role"] == "hospital":
                return redirect(url_for("hospital_dashboard"))
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid username or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out successfully.", "info")
    return redirect(url_for("index"))

# ─── PATIENT ROUTES ───────────────────────────────────────────────────────────

@app.route("/dashboard")
@login_required
@patient_required
def dashboard():
    history = get_patient_history(session["user_id"], limit=5)
    profile = get_patient_profile(session["user_id"])
    return render_template("dashboard.html", history=history, profile=profile)

@app.route("/profile", methods=["GET", "POST"])
@login_required
@patient_required
def profile():
    if request.method == "POST":
        validate_csrf()
        age = clean(request.form.get("age", ""))
        try:
            age = int(age) if age else None
            if age is not None and not (0 < age < 150):
                raise ValueError
        except ValueError:
            flash("Enter a valid age (1–149).", "danger")
            return redirect(url_for("profile"))
        update_patient_profile(
            user_id=session["user_id"],
            age=age,
            gender=clean(request.form.get("gender", "")),
            blood_group=clean(request.form.get("blood_group", "")),
            allergies=clean(request.form.get("allergies", ""), 500),
            medical_history=clean(request.form.get("medical_history", ""), 1000),
        )
        flash("Profile updated successfully!", "success")
        return redirect(url_for("profile"))
    patient = get_patient_profile(session["user_id"])
    return render_template("profile.html", patient=patient)

@app.route("/diagnose", methods=["GET", "POST"])
@login_required
@patient_required
def diagnose():
    all_symptoms = get_all_symptoms()
    result = None
    if request.method == "POST":
        validate_csrf()
        raw_symptoms = clean(request.form.get("symptoms", ""), 500)
        selected     = request.form.getlist("symptom_checkboxes")
        typed        = normalize_symptoms(raw_symptoms)
        all_input    = list(set(typed + selected))
        if not all_input:
            flash("Please enter or select at least one symptom.", "warning")
            return render_template("diagnose.html", all_symptoms=all_symptoms)
        prediction = predict_disease(all_input)
        patient    = get_patient_profile(session["user_id"])
        report     = generate_ai_report(patient or {}, all_input, prediction)
        diag_id    = save_diagnosis(
            user_id=session["user_id"],
            symptoms=", ".join(all_input),
            predicted_disease=prediction["disease"],
            confidence=prediction["confidence"],
            severity=prediction["severity"],
            recommendations=prediction["recommendations"],
            ai_report=report,
        )
        result = {"prediction": prediction, "report": report,
                  "diag_id": diag_id, "symptoms": all_input}
    return render_template("diagnose.html", all_symptoms=all_symptoms, result=result)

@app.route("/history")
@login_required
@patient_required
def history():
    records = get_patient_history(session["user_id"])
    return render_template("history.html", records=records)

@app.route("/report/<int:diag_id>")
@login_required
@patient_required
def view_report(diag_id):
    # IDOR protection – patients can only see their own reports
    diag = get_diagnosis_for_user(diag_id, session["user_id"])
    if not diag:
        flash("Report not found.", "danger")
        return redirect(url_for("history"))
    return render_template("report.html", diag=diag)

# ─── VISUAL ASSESSMENT ────────────────────────────────────────────────────────

@app.route("/visual-assess", methods=["GET", "POST"])
@login_required
@patient_required
def visual_assess():
    result = None
    report = None
    uploaded_image = None
    if request.method == "POST":
        validate_csrf()
        area        = clean(request.form.get("area", "skin"))
        description = clean(request.form.get("description", ""), 500)
        if "image" not in request.files or request.files["image"].filename == "":
            flash("Please upload an image to analyze.", "warning")
            return render_template("visual_assess.html", areas=VISUAL_ASSESSMENT_GUIDE)
        file = request.files["image"]
        if not allowed_file(file.filename):
            flash("Only image files are allowed (JPG, PNG, GIF, WEBP).", "danger")
            return render_template("visual_assess.html", areas=VISUAL_ASSESSMENT_GUIDE)
        os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
        filename = secure_filename(f"{session['user_id']}_{file.filename}")
        filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        file.save(filepath)
        uploaded_image = f"uploads/{filename}"
        analysis = analyze_image_with_ai(filepath, area, description)
        patient  = get_patient_profile(session["user_id"]) or {
            "full_name": session["full_name"], "age": "N/A", "gender": "N/A"}
        report   = build_visual_report(analysis, patient, area)
        result   = {"analysis": analysis, "report": report,
                    "area": area, "description": description}
        top      = analysis.get("top_conditions", [{}])
        top_cond = top[0].get("condition", "Visual Assessment") if top else "Visual Assessment"
        top_conf = top[0].get("confidence", 0) if top else 0
        save_diagnosis(
            user_id=session["user_id"],
            symptoms=f"[Visual] Area: {area} | {description[:100]}",
            predicted_disease=top_cond,
            confidence=top_conf,
            severity=analysis.get("urgency", "unknown"),
            recommendations=analysis.get("recommendation", ""),
            ai_report=report,
        )
        flash("Visual assessment complete and saved to your history!", "success")
    return render_template("visual_assess.html",
                           areas=VISUAL_ASSESSMENT_GUIDE, result=result,
                           uploaded_image=uploaded_image)

# ─── NEARBY DOCTORS ──────────────────────────────────────────────────────────

@app.route("/nearby-doctors")
@login_required
@patient_required
def nearby_doctors():
    disease    = clean(request.args.get("disease", ""), 100)
    specialists = get_specialists_for_disease(disease) if disease else ["General Physician"]
    return render_template("nearby_doctors.html", disease=disease,
                           specialists=specialists,
                           all_specialists=list(DISEASE_TO_SPECIALIST.keys()))

@app.route("/api/find-doctors", methods=["POST"])
@login_required
@patient_required
def api_find_doctors():
    data      = request.get_json(silent=True) or {}
    lat       = data.get("lat")
    lng       = data.get("lng")
    disease   = str(data.get("disease", ""))[:100]
    radius_km = min(int(data.get("radius", 50)), 100)
    if not lat or not lng:
        return jsonify({"error": "Location not provided"}), 400
    result = find_nearby_doctors(lat, lng, disease=disease, radius_km=radius_km)
    return jsonify(result)

# ─── ADMIN ROUTES ─────────────────────────────────────────────────────────────

# ═══════════════════════════════════════════════════════════════════════════════
# ADMIN PANEL — FULLY SECURED
# ═══════════════════════════════════════════════════════════════════════════════

def admin_log(action, detail=""):
    """Log admin action to DB + console."""
    import datetime
    username = session.get("username", "unknown")
    ip = request.remote_addr or "unknown"
    print(f"[ADMIN] {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | "
          f"User:{username} IP:{ip} | {action} | {detail}")
    try:
        admin_log_to_db(username, action, detail, ip)
    except Exception as e:
        print(f"[ADMIN LOG ERROR] {e}")

@app.route("/admin")
@login_required
@admin_required
def admin():
    stats    = admin_get_stats()
    activity = admin_get_activity_log()   # recent diagnoses/prescriptions
    actions  = admin_get_action_log(50)   # admin actions log
    return render_template("admin_dashboard.html", stats=stats, activity=activity, actions=actions)

@app.route("/admin/patients")
@login_required
@admin_required
def admin_patients():
    patients = admin_get_all_patients()
    return render_template("admin_patients.html", patients=patients)

@app.route("/admin/hospitals")
@login_required
@admin_required
def admin_hospitals():
    hospitals = admin_get_all_hospitals()
    return render_template("admin_hospitals.html", hospitals=hospitals)

@app.route("/admin/diagnoses")
@login_required
@admin_required
def admin_diagnoses():
    diagnoses = admin_get_all_diagnoses()
    return render_template("admin_diagnoses.html", diagnoses=diagnoses)

@app.route("/admin/prescriptions")
@login_required
@admin_required
def admin_prescriptions():
    prescriptions = admin_get_all_prescriptions()
    return render_template("admin_prescriptions.html", prescriptions=prescriptions)

@app.route("/admin/doctors")
@login_required
@admin_required
def admin_doctors():
    doctors = admin_get_all_hospital_doctors()
    return render_template("admin_doctors.html", doctors=doctors)

@app.route("/admin/users")
@login_required
@admin_required
def admin_users():
    users = admin_get_all_users()
    return render_template("admin_users.html", users=users)

@app.route("/admin/user/<int:user_id>")
@login_required
@admin_required
def admin_user_detail(user_id):
    user = admin_get_user_by_id(user_id)
    if not user:
        flash("User not found.", "danger")
        return redirect(url_for("admin_users"))
    diagnoses = get_patient_history(user_id, limit=20) if user["role"] == "patient" else []
    prescriptions = get_prescriptions(user_id, limit=20)
    hosp_doctors = get_doctors_for_hospital(user_id) if user["role"] == "hospital" else []
    return render_template("admin_user_detail.html",
        user=user, diagnoses=diagnoses,
        prescriptions=prescriptions, hosp_doctors=hosp_doctors)

@app.route("/admin/delete-user/<int:user_id>", methods=["POST"])
@login_required
@admin_required
def admin_del_user(user_id):
    if user_id == session.get("user_id"):
        flash("You cannot delete your own admin account.", "danger")
        return redirect(url_for("admin_users"))
    user = admin_get_user_by_id(user_id)
    ok, msg = admin_delete_user(user_id)
    if ok:
        admin_log("DELETE_USER", f"id={user_id} name={user.get('full_name') if user else '?'}")
        flash(f"User deleted: {user.get('full_name') if user else user_id}", "success")
    else:
        flash(f"Error: {msg}", "danger")
    return redirect(url_for("admin_users"))

@app.route("/admin/delete-diagnosis/<int:diag_id>", methods=["POST"])
@login_required
@admin_required
def admin_del_diagnosis(diag_id):
    admin_delete_diagnosis(diag_id)
    admin_log("DELETE_DIAGNOSIS", f"id={diag_id}")
    flash("Diagnosis record deleted.", "success")
    return redirect(url_for("admin_diagnoses"))

@app.route("/admin/delete-prescription/<int:pid>", methods=["POST"])
@login_required
@admin_required
def admin_del_prescription(pid):
    admin_delete_prescription(pid)
    admin_log("DELETE_PRESCRIPTION", f"id={pid}")
    flash("Prescription deleted.", "success")
    return redirect(url_for("admin_prescriptions"))

@app.route("/admin/delete-doctor/<int:doc_id>", methods=["POST"])
@login_required
@admin_required
def admin_del_doctor(doc_id):
    admin_delete_hospital_doctor(doc_id)
    admin_log("DELETE_DOCTOR", f"id={doc_id}")
    flash("Doctor record deleted.", "success")
    return redirect(url_for("admin_doctors"))

@app.route("/admin/reset-password/<int:user_id>", methods=["POST"])
@login_required
@admin_required
def admin_reset_pwd(user_id):
    new_pwd = request.form.get("new_password","").strip()
    if len(new_pwd) < 8:
        flash("New password must be at least 8 characters.", "danger")
        return redirect(url_for("admin_user_detail", user_id=user_id))
    admin_reset_password(user_id, new_pwd)
    admin_log("RESET_PASSWORD", f"user_id={user_id}")
    flash("Password reset successfully.", "success")
    return redirect(url_for("admin_user_detail", user_id=user_id))

@app.route("/admin/toggle-role/<int:user_id>", methods=["POST"])
@login_required
@admin_required
def admin_toggle_role(user_id):
    if user_id == session.get("user_id"):
        flash("Cannot change your own role.", "danger")
        return redirect(url_for("admin_users"))
    new_role = request.form.get("new_role","patient")
    if new_role not in ("patient","hospital","admin"):
        flash("Invalid role.", "danger")
        return redirect(url_for("admin_users"))
    admin_toggle_user_role(user_id, new_role)
    admin_log("CHANGE_ROLE", f"user_id={user_id} new_role={new_role}")
    flash(f"Role updated to {new_role}.", "success")
    return redirect(url_for("admin_users"))

# Admins may need to view any report
@app.route("/admin/report/<int:diag_id>")
@login_required
@admin_required
def admin_view_report(diag_id):
    diag = get_diagnosis_by_id(diag_id)
    if not diag:
        flash("Report not found.", "danger")
        return redirect(url_for("admin"))
    return render_template("report.html", diag=diag)

# ─── HOSPITAL ROUTES ──────────────────────────────────────────────────────────

@app.route("/hospital/dashboard")
@login_required
@hospital_required
def hospital_dashboard():
    profile  = get_hospital_profile(session["user_id"])
    doctors  = get_doctors_for_hospital(session["user_id"])
    available = [d for d in doctors if d["available_today"]]
    return render_template("hospital_dashboard.html",
                           profile=profile, doctors=doctors,
                           available_count=len(available))

@app.route("/hospital/profile", methods=["GET", "POST"])
@login_required
@hospital_required
def hospital_profile():
    if request.method == "POST":
        validate_csrf()
        update_hospital_profile(
            user_id=session["user_id"],
            hospital_name=clean(request.form.get("hospital_name", ""), 200),
            address=clean(request.form.get("address", ""), 400),
            contact_number=clean(request.form.get("contact_number", ""), 20),
            registration_number=clean(request.form.get("registration_number", ""), 50),
            about=clean(request.form.get("about", ""), 1000),
        )
        flash("Hospital profile updated!", "success")
        return redirect(url_for("hospital_profile"))
    profile = get_hospital_profile(session["user_id"])
    return render_template("hospital_profile.html", profile=profile)

@app.route("/hospital/doctors")
@login_required
@hospital_required
def hospital_doctors():
    doctors = get_doctors_for_hospital(session["user_id"])
    return render_template("hospital_doctors.html", doctors=doctors)

@app.route("/hospital/doctors/add", methods=["GET", "POST"])
@login_required
@hospital_required
def hospital_add_doctor():
    if request.method == "POST":
        validate_csrf()
        name      = clean(request.form.get("name", ""))
        spec      = clean(request.form.get("specialization", ""))
        if not name or not spec:
            flash("Doctor name and specialization are required.", "danger")
            return render_template("hospital_doctor_form.html", doctor=None, action="Add")
        try:
            exp = int(request.form.get("experience_years") or 0)
        except ValueError:
            exp = 0
        add_doctor(
            hospital_user_id = session["user_id"],
            name             = name,
            specialization   = spec,
            qualification    = clean(request.form.get("qualification", "")),
            experience_years = exp,
            timings          = clean(request.form.get("timings", ""), 300),
            available_today  = bool(request.form.get("available_today")),
            consultation_fee = clean(request.form.get("consultation_fee", ""), 50),
            contact_number   = clean(request.form.get("contact_number", ""), 20),
            about            = clean(request.form.get("about", ""), 600),
        )
        flash(f"Dr. {name} added successfully!", "success")
        return redirect(url_for("hospital_doctors"))
    return render_template("hospital_doctor_form.html", doctor=None, action="Add")

@app.route("/hospital/doctors/edit/<int:doctor_id>", methods=["GET", "POST"])
@login_required
@hospital_required
def hospital_edit_doctor(doctor_id):
    doctor = get_doctor_for_hospital(doctor_id, session["user_id"])
    if not doctor:
        flash("Doctor not found.", "danger")
        return redirect(url_for("hospital_doctors"))
    if request.method == "POST":
        validate_csrf()
        name = clean(request.form.get("name", ""))
        spec = clean(request.form.get("specialization", ""))
        if not name or not spec:
            flash("Doctor name and specialization are required.", "danger")
            return render_template("hospital_doctor_form.html", doctor=doctor, action="Edit")
        try:
            exp = int(request.form.get("experience_years") or 0)
        except ValueError:
            exp = 0
        update_doctor(
            doctor_id        = doctor_id,
            hospital_user_id = session["user_id"],
            name             = name,
            specialization   = spec,
            qualification    = clean(request.form.get("qualification", "")),
            experience_years = exp,
            timings          = clean(request.form.get("timings", ""), 300),
            available_today  = bool(request.form.get("available_today")),
            consultation_fee = clean(request.form.get("consultation_fee", ""), 50),
            contact_number   = clean(request.form.get("contact_number", ""), 20),
            about            = clean(request.form.get("about", ""), 600),
        )
        flash(f"Dr. {name} updated!", "success")
        return redirect(url_for("hospital_doctors"))
    return render_template("hospital_doctor_form.html", doctor=doctor, action="Edit")

@app.route("/hospital/doctors/toggle/<int:doctor_id>", methods=["POST"])
@login_required
@hospital_required
def hospital_toggle_doctor(doctor_id):
    validate_csrf()
    result = toggle_doctor_availability(doctor_id, session["user_id"])
    if result is None:
        flash("Doctor not found.", "danger")
    else:
        status = "Available" if result else "Unavailable"
        flash(f"Doctor marked as {status} today.", "success")
    return redirect(url_for("hospital_doctors"))

@app.route("/hospital/doctors/delete/<int:doctor_id>", methods=["POST"])
@login_required
@hospital_required
def hospital_delete_doctor(doctor_id):
    validate_csrf()
    doctor = get_doctor_for_hospital(doctor_id, session["user_id"])
    if not doctor:
        flash("Doctor not found.", "danger")
        return redirect(url_for("hospital_doctors"))
    deleted = delete_doctor(doctor_id, session["user_id"])
    if deleted:
        flash(f"Dr. {doctor['name']} removed from your list.", "success")
    else:
        flash("Could not delete doctor.", "danger")
    return redirect(url_for("hospital_doctors"))

# ─── SHARED API ENDPOINTS ─────────────────────────────────────────────────────

@app.route("/api/quick-diagnose", methods=["POST"])
@login_required
@patient_required
def api_quick_diagnose():
    data     = request.get_json(silent=True) or {}
    symptoms = data.get("symptoms", [])
    if not symptoms:
        return jsonify({"error": "No symptoms provided"}), 400
    result = predict_disease(symptoms)
    return jsonify(result)

@app.route("/api/symptoms")
@login_required
def api_symptoms():
    return jsonify(get_all_symptoms())

# ─── INIT & RUN ──────────────────────────────────────────────────────────────


# ─── PRESCRIPTION ────────────────────────────────────────────────────────────

@app.route("/prescription", methods=["GET","POST"])
@login_required
def prescription():
    if session.get("role") == "hospital":
        flash("Prescription upload is for patients only.", "warning")
        return redirect(url_for("hospital_dashboard"))
    history = get_prescriptions(session["user_id"], limit=10)
    result = None
    if request.method == "POST":
        text_input = request.form.get("medicine_text","").strip()
        img_file   = request.files.get("prescription_image")
        image_path = None
        if img_file and img_file.filename and allowed_file(img_file.filename):
            os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
            fname = secure_filename(f"rx_{session['user_id']}_{img_file.filename}")
            image_path = os.path.join(app.config["UPLOAD_FOLDER"], fname)
            img_file.save(image_path)
        if not image_path and not text_input:
            flash("Upload a prescription image or type medicine names.", "warning")
            return render_template("prescription.html", history=history)
        analysis = analyze_prescription_with_ai(image_path=image_path, text_content=text_input)
        if text_input and not analysis.get("medicines"):
            from prescription_analyzer import _rule_based_analysis
            analysis = _rule_based_analysis(text_input)
        report = build_prescription_report(analysis, patient_name=session.get("full_name",""))
        meds_str = ", ".join([m["name"] for m in analysis.get("medicines",[])])
        pid = save_prescription(
            user_id=session["user_id"],
            image_path=image_path or "",
            raw_text=text_input,
            analysis_json=analysis,
            report=report,
            medicines_found=meds_str
        )
        result = {"analysis":analysis,"report":report,"medicines":analysis.get("medicines",[]),"pid":pid,"image_path":image_path}
        flash("Prescription analyzed and saved!", "success")
        history = get_prescriptions(session["user_id"], limit=10)
    return render_template("prescription.html", history=history, result=result)


@app.route("/prescription/<int:pid>")
@login_required
def view_prescription(pid):
    p = get_prescription_by_id(pid, session["user_id"])
    if not p:
        flash("Prescription not found.", "danger")
        return redirect(url_for("prescription"))
    return render_template("prescription_detail.html", p=p)


if __name__ == "__main__":
    init_db()
    print("[ML] Training model...")
    train_model()
    print("[App] Starting Medical Diagnosis Assistant...")
    app.run(debug=False, host="0.0.0.0", port=5000)
