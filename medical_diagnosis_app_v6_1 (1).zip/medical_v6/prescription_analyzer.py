import os, base64, json

MEDICINE_DB = {
    "paracetamol": {
        "generic": "Paracetamol (Acetaminophen)", "category": "Analgesic / Antipyretic",
        "use": "Fever, mild to moderate pain, headache",
        "side_effects": "Rare at normal doses; overdose causes liver damage",
        "alternatives": ["Ibuprofen", "Aspirin", "Diclofenac"], "otc": True,
    },
    "ibuprofen": {
        "generic": "Ibuprofen", "category": "NSAID Anti-inflammatory",
        "use": "Pain, inflammation, fever, arthritis",
        "side_effects": "Stomach upset, nausea — avoid on empty stomach",
        "alternatives": ["Paracetamol", "Naproxen", "Diclofenac"], "otc": True,
    },
    "aspirin": {
        "generic": "Aspirin (Acetylsalicylic Acid)", "category": "NSAID / Antiplatelet",
        "use": "Pain, fever, heart attack/stroke prevention",
        "side_effects": "GI bleeding risk; avoid in children under 16",
        "alternatives": ["Paracetamol", "Ibuprofen"], "otc": True,
    },
    "diclofenac": {
        "generic": "Diclofenac Sodium", "category": "NSAID",
        "use": "Arthritis, pain, inflammation, muscle pain",
        "side_effects": "GI discomfort, kidney issues with long-term use",
        "alternatives": ["Ibuprofen", "Naproxen", "Paracetamol"], "otc": False,
    },
    "amoxicillin": {
        "generic": "Amoxicillin", "category": "Antibiotic (Penicillin)",
        "use": "Bacterial infections: throat, ear, chest, UTI",
        "side_effects": "Nausea, diarrhea, allergic rash",
        "alternatives": ["Azithromycin", "Clarithromycin", "Cefalexin"], "otc": False,
    },
    "azithromycin": {
        "generic": "Azithromycin", "category": "Antibiotic (Macrolide)",
        "use": "Respiratory, skin, and sexually transmitted infections",
        "side_effects": "Nausea, abdominal pain, diarrhea",
        "alternatives": ["Amoxicillin", "Clarithromycin", "Doxycycline"], "otc": False,
    },
    "ciprofloxacin": {
        "generic": "Ciprofloxacin", "category": "Antibiotic (Fluoroquinolone)",
        "use": "UTI, diarrhea, respiratory and skin infections",
        "side_effects": "Nausea, dizziness, tendon damage risk",
        "alternatives": ["Amoxicillin", "Cefalexin", "Azithromycin"], "otc": False,
    },
    "metronidazole": {
        "generic": "Metronidazole", "category": "Antibiotic / Antiprotozoal",
        "use": "Bacterial and parasitic infections, dental infections",
        "side_effects": "Nausea, metallic taste, avoid alcohol",
        "alternatives": ["Tinidazole", "Clindamycin"], "otc": False,
    },
    "omeprazole": {
        "generic": "Omeprazole", "category": "Proton Pump Inhibitor (PPI)",
        "use": "Acid reflux, GERD, stomach ulcers, heartburn",
        "side_effects": "Headache, nausea, B12 deficiency (long-term)",
        "alternatives": ["Pantoprazole", "Lansoprazole", "Antacids"], "otc": True,
    },
    "pantoprazole": {
        "generic": "Pantoprazole", "category": "Proton Pump Inhibitor (PPI)",
        "use": "GERD, stomach ulcers, excess acid",
        "side_effects": "Headache, diarrhea, nausea",
        "alternatives": ["Omeprazole", "Lansoprazole", "Antacids"], "otc": False,
    },
    "cetirizine": {
        "generic": "Cetirizine HCl", "category": "Antihistamine",
        "use": "Allergic rhinitis, urticaria, hay fever, itching",
        "side_effects": "Drowsiness, dry mouth, headache",
        "alternatives": ["Loratadine", "Fexofenadine", "Levocetirizine"], "otc": True,
    },
    "loratadine": {
        "generic": "Loratadine", "category": "Non-drowsy Antihistamine",
        "use": "Allergies, hay fever, hives",
        "side_effects": "Minimal; headache, dry mouth",
        "alternatives": ["Cetirizine", "Fexofenadine"], "otc": True,
    },
    "metformin": {
        "generic": "Metformin HCl", "category": "Antidiabetic (Biguanide)",
        "use": "Type 2 Diabetes management",
        "side_effects": "GI disturbance, lactic acidosis (rare)",
        "alternatives": ["Glipizide", "Sitagliptin", "Empagliflozin"], "otc": False,
    },
    "amlodipine": {
        "generic": "Amlodipine Besylate", "category": "Calcium Channel Blocker",
        "use": "Hypertension, angina",
        "side_effects": "Swollen ankles, headache, flushing",
        "alternatives": ["Nifedipine", "Atenolol", "Losartan"], "otc": False,
    },
    "atenolol": {
        "generic": "Atenolol", "category": "Beta Blocker",
        "use": "Hypertension, heart conditions, angina",
        "side_effects": "Fatigue, cold hands, slow heart rate",
        "alternatives": ["Metoprolol", "Amlodipine", "Bisoprolol"], "otc": False,
    },
    "salbutamol": {
        "generic": "Salbutamol (Albuterol)", "category": "Bronchodilator",
        "use": "Asthma, COPD, bronchospasm",
        "side_effects": "Tremors, palpitations, headache",
        "alternatives": ["Formoterol", "Terbutaline", "Ipratropium"], "otc": False,
    },
    "vitamin c": {
        "generic": "Ascorbic Acid (Vitamin C)", "category": "Vitamin / Supplement",
        "use": "Immune support, antioxidant, collagen synthesis",
        "side_effects": "High doses may cause stomach upset or kidney stones",
        "alternatives": ["Multivitamin", "Zinc supplement"], "otc": True,
    },
    "vitamin d": {
        "generic": "Cholecalciferol (Vitamin D3)", "category": "Vitamin / Supplement",
        "use": "Bone health, calcium absorption, immune function",
        "side_effects": "Toxicity with very high doses",
        "alternatives": ["Calcitriol", "Cod liver oil"], "otc": True,
    },
    "dextromethorphan": {
        "generic": "Dextromethorphan", "category": "Cough Suppressant",
        "use": "Dry / non-productive cough",
        "side_effects": "Drowsiness, dizziness, nausea",
        "alternatives": ["Honey (natural)", "Codeine (Rx)"], "otc": True,
    },
    "prednisolone": {
        "generic": "Prednisolone", "category": "Corticosteroid",
        "use": "Inflammation, allergy, autoimmune conditions, asthma",
        "side_effects": "Weight gain, mood changes, increased blood sugar",
        "alternatives": ["Dexamethasone", "Hydrocortisone", "Methylprednisolone"], "otc": False,
    },
    "ondansetron": {
        "generic": "Ondansetron", "category": "Antiemetic",
        "use": "Nausea and vomiting (chemo, surgery, pregnancy)",
        "side_effects": "Headache, constipation, dizziness",
        "alternatives": ["Domperidone", "Metoclopramide", "Promethazine"], "otc": False,
    },
}

BRAND_MAP = {
    "crocin": "paracetamol", "tylenol": "paracetamol", "calpol": "paracetamol", "dolo": "paracetamol",
    "brufen": "ibuprofen", "advil": "ibuprofen", "combiflam": "ibuprofen",
    "augmentin": "amoxicillin", "mox": "amoxicillin",
    "zithromax": "azithromycin", "azee": "azithromycin",
    "cipro": "ciprofloxacin", "ciplox": "ciprofloxacin",
    "flagyl": "metronidazole", "metrogyl": "metronidazole",
    "prilosec": "omeprazole", "omez": "omeprazole",
    "pan": "pantoprazole", "pantodac": "pantoprazole",
    "zyrtec": "cetirizine", "alerid": "cetirizine",
    "claritin": "loratadine",
    "glucophage": "metformin", "glycomet": "metformin",
    "norvasc": "amlodipine", "amlip": "amlodipine",
    "ventolin": "salbutamol", "asthalin": "salbutamol",
    "ondansetron": "ondansetron", "emeset": "ondansetron",
}

def extract_medicines_from_text(text):
    text_lower = text.lower()
    found, seen = [], set()
    for key, info in MEDICINE_DB.items():
        if key in text_lower and key not in seen:
            item = info.copy()
            item["name_found"] = key.title()
            item["key"] = key
            found.append(item)
            seen.add(key)
    for brand, gkey in BRAND_MAP.items():
        if brand in text_lower and gkey not in seen:
            item = MEDICINE_DB[gkey].copy()
            item["name_found"] = f"{brand.title()} (Generic: {gkey.title()})"
            item["key"] = gkey
            found.append(item)
            seen.add(gkey)
    return found

def _rule_based_analysis(text, error=None):
    medicines_found = extract_medicines_from_text(text) if text else []
    result = {
        "method": "text_analysis",
        "patient_name": None, "doctor_name": None, "date": None,
        "medicines": [], "diagnosis": None,
        "notes": "Add OpenAI API key to enable image-based reading.",
    }
    if error:
        result["api_error"] = error
    for med in medicines_found:
        result["medicines"].append({
            "name": med["name_found"],
            "dosage": "As prescribed", "frequency": "As prescribed",
            "duration": "As prescribed", "instructions": "",
            "db_info": {
                "generic": med["generic"], "category": med["category"],
                "use": med["use"], "side_effects": med["side_effects"],
                "alternatives": med["alternatives"], "otc": med["otc"],
            }
        })
    return result

def analyze_prescription_with_ai(image_path=None, text_content=None):
    api_key = os.getenv("OPENAI_API_KEY", "")
    if api_key and image_path and os.path.exists(image_path):
        return _ai_vision_analysis(image_path, api_key)
    return _rule_based_analysis(text_content or "")

def _ai_vision_analysis(image_path, api_key):
    try:
        import openai
        client = openai.OpenAI(api_key=api_key)
        with open(image_path, "rb") as f:
            img_b64 = base64.b64encode(f.read()).decode()
        ext = image_path.rsplit(".", 1)[-1].lower()
        mime = "image/jpeg" if ext in ["jpg","jpeg"] else "image/png"
        prompt = '''Analyze this prescription image. Return ONLY JSON:
{
  "patient_name": null,
  "doctor_name": null,
  "date": null,
  "diagnosis": null,
  "medicines": [
    {"name":"","dosage":"","frequency":"","duration":"","instructions":""}
  ],
  "notes": ""
}'''
        resp = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role":"user","content":[
                {"type":"text","text":prompt},
                {"type":"image_url","image_url":{"url":f"data:{mime};base64,{img_b64}","detail":"high"}}
            ]}],
            max_tokens=1000
        )
        raw = resp.choices[0].message.content.strip()
        for wrap in ["```json","```"]:
            if wrap in raw:
                raw = raw.split(wrap)[1].split("```")[0].strip()
                break
        data = json.loads(raw)
        data["method"] = "gpt4_vision"
        enriched = []
        for med in data.get("medicines", []):
            mname = med.get("name","").lower()
            db_info = None
            for key in MEDICINE_DB:
                if key in mname or mname in key:
                    db_info = MEDICINE_DB[key]
                    break
            if not db_info:
                for brand, gkey in BRAND_MAP.items():
                    if brand in mname:
                        db_info = MEDICINE_DB[gkey]
                        break
            med["db_info"] = db_info
            enriched.append(med)
        data["medicines"] = enriched
        return data
    except Exception as e:
        return _rule_based_analysis("", error=str(e))

def build_prescription_report(analysis, patient_name=""):
    method = "GPT-4 Vision AI" if analysis.get("method") == "gpt4_vision" else "Text Pattern Analysis"
    meds = analysis.get("medicines", [])
    report = f"""╔══════════════════════════════════════════════╗
   PRESCRIPTION BREAKDOWN REPORT
   Method: {method}
╚══════════════════════════════════════════════╝

PRESCRIPTION DETAILS
────────────────────
Patient  : {analysis.get('patient_name') or patient_name or 'N/A'}
Doctor   : {analysis.get('doctor_name') or 'N/A'}
Date     : {analysis.get('date') or 'N/A'}
Diagnosis: {analysis.get('diagnosis') or 'N/A'}

MEDICINES FOUND: {len(meds)}
────────────────────────────────────────────"""
    for i, med in enumerate(meds, 1):
        db = med.get("db_info") or {}
        alts = ", ".join(db.get("alternatives", [])) or "Consult doctor"
        report += f"""

{i}. {med['name']}
   Dosage      : {med.get('dosage','As prescribed')}
   Frequency   : {med.get('frequency','As prescribed')}
   Duration    : {med.get('duration','As prescribed')}
   Category    : {db.get('category','N/A')}
   Used for    : {db.get('use','N/A')}
   Side Effects: {db.get('side_effects','N/A')}
   OTC         : {'Yes' if db.get('otc') else 'No (Prescription required)'}
   Alternatives: {alts}"""
    report += """

────────────────────────────────────────────
⚠️  DISCLAIMER: For informational purposes only.
Always follow your doctor's prescription exactly.
Consult doctor before switching to any alternative.
────────────────────────────────────────────"""
    return report.strip()
