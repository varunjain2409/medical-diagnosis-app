import sqlite3
import os
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

DB_PATH = "medical_app.db"

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            full_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            role TEXT DEFAULT 'patient',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS patients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE,
            age INTEGER,
            gender TEXT,
            blood_group TEXT,
            allergies TEXT,
            medical_history TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS diagnoses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id INTEGER NOT NULL,
            symptoms TEXT NOT NULL,
            predicted_disease TEXT,
            confidence REAL,
            severity TEXT,
            recommendations TEXT,
            ai_report TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (patient_id) REFERENCES patients(id)
        );

        CREATE TABLE IF NOT EXISTS symptoms_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            diagnosis_id INTEGER,
            symptom_name TEXT NOT NULL,
            severity_level INTEGER DEFAULT 1,
            FOREIGN KEY (diagnosis_id) REFERENCES diagnoses(id)
        );

        CREATE TABLE IF NOT EXISTS doctors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE,
            specialization TEXT,
            hospital TEXT,
            contact TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS hospitals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE NOT NULL,
            hospital_name TEXT NOT NULL,
            address TEXT,
            contact_number TEXT,
            registration_number TEXT,
            about TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS admin_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_username TEXT NOT NULL,
            action TEXT NOT NULL,
            detail TEXT,
            ip_address TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS prescriptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            image_path TEXT,
            raw_text TEXT,
            analysis_json TEXT,
            report TEXT,
            medicines_found TEXT,
            uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS hospital_doctors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hospital_user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            specialization TEXT NOT NULL,
            qualification TEXT,
            experience_years INTEGER,
            timings TEXT,
            available_today INTEGER DEFAULT 1,
            consultation_fee TEXT,
            contact_number TEXT,
            about TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (hospital_user_id) REFERENCES users(id)
        );
    """)

    # Seed default admin user (password hashed with a salted PBKDF2 hash)
    # Credentials come from environment variables so nothing sensitive is
    # hardcoded in the source. If ADMIN_PASSWORD isn't set, a random one-time
    # password is generated and printed to the console (not stored anywhere).
    admin_username = os.environ.get("ADMIN_USERNAME", "admin")
    admin_password = os.environ.get("ADMIN_PASSWORD")

    cursor.execute("SELECT id FROM users WHERE username = ?", (admin_username,))
    admin_exists = cursor.fetchone() is not None

    if not admin_exists and not admin_password:
        import secrets
        admin_password = secrets.token_urlsafe(12)
        print("=" * 60)
        print("[DB] No ADMIN_PASSWORD set — generated a one-time password:")
        print(f"[DB]   Username: {admin_username}")
        print(f"[DB]   Password: {admin_password}")
        print("[DB] Save this now — it will not be shown again.")
        print("[DB] Set ADMIN_USERNAME / ADMIN_PASSWORD env vars to control this.")
        print("=" * 60)

    if admin_password:
        cursor.execute("""
            INSERT OR IGNORE INTO users (username, password_hash, full_name, email, role)
            VALUES (?, ?, 'Administrator', 'admin@mediai.com', 'admin')
        """, (admin_username, generate_password_hash(admin_password)))

    conn.commit()
    conn.close()
    print("[DB] Database initialized successfully.")

# ─── USER FUNCTIONS ───────────────────────────────────────────────────────────

def register_user(username, password, full_name, email, role="patient",
                   hospital_name=None, hospital_address=None, hospital_contact=None):
    conn = get_connection()
    try:
        conn.execute("""
            INSERT INTO users (username, password_hash, full_name, email, role)
            VALUES (?, ?, ?, ?, ?)
        """, (username, generate_password_hash(password), full_name, email, role))
        user_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

        if role == "hospital":
            conn.execute("""
                INSERT INTO hospitals (user_id, hospital_name, address, contact_number)
                VALUES (?, ?, ?, ?)
            """, (user_id, hospital_name, hospital_address, hospital_contact))
        else:
            conn.execute("INSERT INTO patients (user_id) VALUES (?)", (user_id,))

        conn.commit()
        return True, "Registration successful!"
    except sqlite3.IntegrityError:
        return False, "Username or email already exists."
    finally:
        conn.close()

def login_user(username, password):
    conn = get_connection()
    user = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    if user and check_password_hash(user["password_hash"], password):
        return dict(user)
    return None

def get_user_by_id(user_id):
    conn = get_connection()
    user = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    conn.close()
    return dict(user) if user else None

# ─── PATIENT FUNCTIONS ────────────────────────────────────────────────────────

def get_patient_profile(user_id):
    conn = get_connection()
    patient = conn.execute("""
        SELECT p.*, u.full_name, u.email, u.username
        FROM patients p JOIN users u ON p.user_id = u.id
        WHERE p.user_id = ?
    """, (user_id,)).fetchone()
    conn.close()
    return dict(patient) if patient else None

def update_patient_profile(user_id, age, gender, blood_group, allergies, medical_history):
    conn = get_connection()
    conn.execute("""
        UPDATE patients SET age=?, gender=?, blood_group=?, allergies=?, medical_history=?
        WHERE user_id=?
    """, (age, gender, blood_group, allergies, medical_history, user_id))
    conn.commit()
    conn.close()

# ─── DIAGNOSIS FUNCTIONS ──────────────────────────────────────────────────────

def save_diagnosis(user_id, symptoms, predicted_disease, confidence, severity, recommendations, ai_report):
    conn = get_connection()
    patient = conn.execute("SELECT id FROM patients WHERE user_id=?", (user_id,)).fetchone()
    if not patient:
        conn.close()
        return None
    patient_id = patient["id"]
    cursor = conn.execute("""
        INSERT INTO diagnoses (patient_id, symptoms, predicted_disease, confidence, severity, recommendations, ai_report)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (patient_id, symptoms, predicted_disease, confidence, severity, recommendations, ai_report))
    diag_id = cursor.lastrowid
    for s in symptoms.split(","):
        s = s.strip()
        if s:
            conn.execute("INSERT INTO symptoms_log (diagnosis_id, symptom_name) VALUES (?, ?)", (diag_id, s))
    conn.commit()
    conn.close()
    return diag_id

def get_patient_history(user_id, limit=20):
    conn = get_connection()
    rows = conn.execute("""
        SELECT d.* FROM diagnoses d
        JOIN patients p ON d.patient_id = p.id
        WHERE p.user_id = ?
        ORDER BY d.created_at DESC LIMIT ?
    """, (user_id, limit)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_diagnosis_by_id(diag_id):
    conn = get_connection()
    row = conn.execute("SELECT * FROM diagnoses WHERE id=?", (diag_id,)).fetchone()
    conn.close()
    return dict(row) if row else None

def get_diagnosis_for_user(diag_id, user_id):
    """Fetch a diagnosis only if it belongs to the given user (prevents IDOR)."""
    conn = get_connection()
    row = conn.execute("""
        SELECT d.* FROM diagnoses d
        JOIN patients p ON d.patient_id = p.id
        WHERE d.id = ? AND p.user_id = ?
    """, (diag_id, user_id)).fetchone()
    conn.close()
    return dict(row) if row else None

def get_all_diagnoses_admin():
    conn = get_connection()
    rows = conn.execute("""
        SELECT d.*, u.full_name, u.email
        FROM diagnoses d
        JOIN patients p ON d.patient_id = p.id
        JOIN users u ON p.user_id = u.id
        ORDER BY d.created_at DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]

# ─── HOSPITAL FUNCTIONS ───────────────────────────────────────────────────────

def get_hospital_profile(user_id):
    conn = get_connection()
    row = conn.execute("""
        SELECT h.*, u.full_name, u.email, u.username
        FROM hospitals h JOIN users u ON h.user_id = u.id
        WHERE h.user_id = ?
    """, (user_id,)).fetchone()
    conn.close()
    return dict(row) if row else None

def update_hospital_profile(user_id, hospital_name, address, contact_number, registration_number, about):
    conn = get_connection()
    conn.execute("""
        UPDATE hospitals
        SET hospital_name=?, address=?, contact_number=?, registration_number=?, about=?
        WHERE user_id=?
    """, (hospital_name, address, contact_number, registration_number, about, user_id))
    conn.commit()
    conn.close()

# ─── HOSPITAL DOCTOR-LIST FUNCTIONS ───────────────────────────────────────────

def add_doctor(hospital_user_id, name, specialization, qualification, experience_years,
               timings, available_today, consultation_fee, contact_number, about):
    conn = get_connection()
    cursor = conn.execute("""
        INSERT INTO hospital_doctors
            (hospital_user_id, name, specialization, qualification, experience_years,
             timings, available_today, consultation_fee, contact_number, about, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    """, (hospital_user_id, name, specialization, qualification, experience_years,
          timings, 1 if available_today else 0, consultation_fee, contact_number, about))
    conn.commit()
    doctor_id = cursor.lastrowid
    conn.close()
    return doctor_id

def get_doctors_for_hospital(hospital_user_id):
    conn = get_connection()
    rows = conn.execute("""
        SELECT * FROM hospital_doctors
        WHERE hospital_user_id = ?
        ORDER BY name COLLATE NOCASE
    """, (hospital_user_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_doctor_for_hospital(doctor_id, hospital_user_id):
    """Fetch a doctor only if it belongs to the requesting hospital (prevents IDOR)."""
    conn = get_connection()
    row = conn.execute("""
        SELECT * FROM hospital_doctors WHERE id = ? AND hospital_user_id = ?
    """, (doctor_id, hospital_user_id)).fetchone()
    conn.close()
    return dict(row) if row else None

def update_doctor(doctor_id, hospital_user_id, name, specialization, qualification,
                   experience_years, timings, available_today, consultation_fee,
                   contact_number, about):
    conn = get_connection()
    cursor = conn.execute("""
        UPDATE hospital_doctors
        SET name=?, specialization=?, qualification=?, experience_years=?, timings=?,
            available_today=?, consultation_fee=?, contact_number=?, about=?,
            updated_at=CURRENT_TIMESTAMP
        WHERE id=? AND hospital_user_id=?
    """, (name, specialization, qualification, experience_years, timings,
          1 if available_today else 0, consultation_fee, contact_number, about,
          doctor_id, hospital_user_id))
    conn.commit()
    updated = cursor.rowcount > 0
    conn.close()
    return updated

def toggle_doctor_availability(doctor_id, hospital_user_id):
    conn = get_connection()
    row = conn.execute("""
        SELECT available_today FROM hospital_doctors WHERE id=? AND hospital_user_id=?
    """, (doctor_id, hospital_user_id)).fetchone()
    if not row:
        conn.close()
        return None
    new_value = 0 if row["available_today"] else 1
    conn.execute("""
        UPDATE hospital_doctors SET available_today=?, updated_at=CURRENT_TIMESTAMP
        WHERE id=? AND hospital_user_id=?
    """, (new_value, doctor_id, hospital_user_id))
    conn.commit()
    conn.close()
    return bool(new_value)

def delete_doctor(doctor_id, hospital_user_id):
    conn = get_connection()
    cursor = conn.execute("""
        DELETE FROM hospital_doctors WHERE id=? AND hospital_user_id=?
    """, (doctor_id, hospital_user_id))
    conn.commit()
    deleted = cursor.rowcount > 0
    conn.close()
    return deleted


# ─── PRESCRIPTION FUNCTIONS ───────────────────────────────────────────────────
def save_prescription(user_id, image_path, raw_text, analysis_json, report, medicines_found):
    import json as _json
    conn = get_connection()
    cursor = conn.execute(
        "INSERT INTO prescriptions (user_id,image_path,raw_text,analysis_json,report,medicines_found) VALUES (?,?,?,?,?,?)",
        (user_id, image_path, raw_text,
         _json.dumps(analysis_json) if isinstance(analysis_json, dict) else analysis_json,
         report, medicines_found))
    pid = cursor.lastrowid
    conn.commit(); conn.close()
    return pid

def get_prescriptions(user_id, limit=20):
    import json as _json
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM prescriptions WHERE user_id=? ORDER BY uploaded_at DESC LIMIT ?",
        (user_id, limit)).fetchall()
    conn.close()
    out = []
    for r in rows:
        d = dict(r)
        try: d["analysis"] = _json.loads(d["analysis_json"] or "{}")
        except: d["analysis"] = {}
        out.append(d)
    return out

def get_prescription_by_id(pid, user_id):
    import json as _json
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM prescriptions WHERE id=? AND user_id=?",
        (pid, user_id)).fetchone()
    conn.close()
    if not row: return None
    d = dict(row)
    try: d["analysis"] = _json.loads(d["analysis_json"] or "{}")
    except: d["analysis"] = {}
    return d


# ─── ADMIN DATABASE FUNCTIONS ─────────────────────────────────────────────────

def admin_get_all_users():
    """Get all users with their profiles."""
    conn = get_connection()
    rows = conn.execute("""
        SELECT u.id, u.username, u.full_name, u.email, u.role, u.created_at,
               p.age, p.gender, p.blood_group, p.allergies,
               h.hospital_name, h.address, h.contact_number, h.registration_number
        FROM users u
        LEFT JOIN patients p ON u.id = p.user_id
        LEFT JOIN hospitals h ON u.id = h.user_id
        ORDER BY u.created_at DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def admin_get_stats():
    """Get platform-wide statistics."""
    conn = get_connection()
    stats = {}
    stats['total_users']     = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    stats['total_patients']  = conn.execute("SELECT COUNT(*) FROM users WHERE role='patient'").fetchone()[0]
    stats['total_hospitals'] = conn.execute("SELECT COUNT(*) FROM users WHERE role='hospital'").fetchone()[0]
    stats['total_diagnoses'] = conn.execute("SELECT COUNT(*) FROM diagnoses").fetchone()[0]
    stats['total_prescriptions'] = conn.execute("SELECT COUNT(*) FROM prescriptions").fetchone()[0]
    stats['total_hosp_doctors']  = conn.execute("SELECT COUNT(*) FROM hospital_doctors").fetchone()[0]
    stats['severe_diagnoses'] = conn.execute(
        "SELECT COUNT(*) FROM diagnoses WHERE severity='severe'").fetchone()[0]
    stats['recent_users'] = conn.execute(
        "SELECT COUNT(*) FROM users WHERE DATE(created_at) = DATE('now')").fetchone()[0]
    conn.close()
    return stats

def admin_get_all_patients():
    """Full patient list with profiles and diagnosis count."""
    conn = get_connection()
    rows = conn.execute("""
        SELECT u.id, u.username, u.full_name, u.email, u.created_at,
               p.age, p.gender, p.blood_group, p.allergies, p.medical_history,
               COUNT(d.id) as diagnosis_count
        FROM users u
        LEFT JOIN patients p ON u.id = p.user_id
        LEFT JOIN diagnoses d ON p.id = d.patient_id
        WHERE u.role = 'patient'
        GROUP BY u.id
        ORDER BY u.created_at DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def admin_get_all_hospitals():
    """Full hospital list with doctor count."""
    conn = get_connection()
    rows = conn.execute("""
        SELECT u.id, u.username, u.full_name, u.email, u.created_at,
               h.hospital_name, h.address, h.contact_number, h.registration_number, h.about,
               COUNT(hd.id) as doctor_count,
               SUM(hd.available_today) as available_today
        FROM users u
        LEFT JOIN hospitals h ON u.id = h.user_id
        LEFT JOIN hospital_doctors hd ON u.id = hd.hospital_user_id
        WHERE u.role = 'hospital'
        GROUP BY u.id
        ORDER BY u.created_at DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def admin_get_all_diagnoses():
    """All diagnoses with patient info."""
    conn = get_connection()
    rows = conn.execute("""
        SELECT d.*, u.full_name, u.email, u.username
        FROM diagnoses d
        JOIN patients p ON d.patient_id = p.id
        JOIN users u ON p.user_id = u.id
        ORDER BY d.created_at DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def admin_get_all_prescriptions():
    """All prescriptions with patient info."""
    conn = get_connection()
    rows = conn.execute("""
        SELECT pr.*, u.full_name, u.email
        FROM prescriptions pr
        JOIN users u ON pr.user_id = u.id
        ORDER BY pr.uploaded_at DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def admin_get_all_hospital_doctors():
    """All hospital doctors across all hospitals."""
    conn = get_connection()
    rows = conn.execute("""
        SELECT hd.*, u.full_name as hospital_name, h.hospital_name as h_name
        FROM hospital_doctors hd
        JOIN users u ON hd.hospital_user_id = u.id
        LEFT JOIN hospitals h ON hd.hospital_user_id = h.user_id
        ORDER BY hd.created_at DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def admin_delete_user(user_id):
    """Delete a user and all related data."""
    conn = get_connection()
    try:
        # Get patient id first
        patient = conn.execute("SELECT id FROM patients WHERE user_id=?", (user_id,)).fetchone()
        if patient:
            conn.execute("DELETE FROM symptoms_log WHERE diagnosis_id IN (SELECT id FROM diagnoses WHERE patient_id=?)", (patient['id'],))
            conn.execute("DELETE FROM diagnoses WHERE patient_id=?", (patient['id'],))
            conn.execute("DELETE FROM patients WHERE user_id=?", (user_id,))
        conn.execute("DELETE FROM prescriptions WHERE user_id=?", (user_id,))
        conn.execute("DELETE FROM hospital_doctors WHERE hospital_user_id=?", (user_id,))
        conn.execute("DELETE FROM hospitals WHERE user_id=?", (user_id,))
        conn.execute("DELETE FROM users WHERE id=?", (user_id,))
        conn.commit()
        return True, "User deleted successfully."
    except Exception as e:
        conn.rollback()
        return False, str(e)
    finally:
        conn.close()

def admin_delete_diagnosis(diag_id):
    """Delete a diagnosis record."""
    conn = get_connection()
    conn.execute("DELETE FROM symptoms_log WHERE diagnosis_id=?", (diag_id,))
    conn.execute("DELETE FROM diagnoses WHERE id=?", (diag_id,))
    conn.commit()
    conn.close()

def admin_delete_prescription(pid):
    """Delete a prescription record."""
    conn = get_connection()
    conn.execute("DELETE FROM prescriptions WHERE id=?", (pid,))
    conn.commit()
    conn.close()

def admin_delete_hospital_doctor(doc_id):
    """Delete a hospital doctor."""
    conn = get_connection()
    conn.execute("DELETE FROM hospital_doctors WHERE id=?", (doc_id,))
    conn.commit()
    conn.close()

def admin_reset_password(user_id, new_password):
    """Reset a user password."""
    from werkzeug.security import generate_password_hash
    conn = get_connection()
    conn.execute("UPDATE users SET password_hash=? WHERE id=?",
                 (generate_password_hash(new_password), user_id))
    conn.commit()
    conn.close()

def admin_toggle_user_role(user_id, new_role):
    """Change a user's role."""
    conn = get_connection()
    conn.execute("UPDATE users SET role=? WHERE id=?", (new_role, user_id))
    conn.commit()
    conn.close()

def admin_log_to_db(admin_username, action, detail="", ip_address=""):
    conn = get_connection()
    conn.execute("""
        INSERT INTO admin_logs (admin_username, action, detail, ip_address)
        VALUES (?, ?, ?, ?)
    """, (admin_username, action, detail, ip_address))
    conn.commit()
    conn.close()

def admin_get_activity_log():
    """Recent activity across all users."""
    conn = get_connection()
    rows = conn.execute("""
        SELECT 'Diagnosis' as type, d.created_at as time,
               u.full_name as user, d.predicted_disease as detail, d.severity
        FROM diagnoses d
        JOIN patients p ON d.patient_id = p.id
        JOIN users u ON p.user_id = u.id
        UNION ALL
        SELECT 'Prescription' as type, pr.uploaded_at as time,
               u.full_name as user, pr.medicines_found as detail, '' as severity
        FROM prescriptions pr
        JOIN users u ON pr.user_id = u.id
        ORDER BY time DESC LIMIT 50
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def admin_get_action_log(limit=50):
    """Get admin action log from admin_logs table."""
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT * FROM admin_logs ORDER BY created_at DESC LIMIT ?
        """, (limit,)).fetchall()
        conn.close()
        return [dict(r) for r in rows]
    except:
        conn.close()
        return []

def admin_get_user_by_id(user_id):
    conn = get_connection()
    row = conn.execute("""
        SELECT u.*, p.age, p.gender, p.blood_group, p.allergies, p.medical_history,
               h.hospital_name, h.address, h.contact_number, h.registration_number, h.about
        FROM users u
        LEFT JOIN patients p ON u.id = p.user_id
        LEFT JOIN hospitals h ON u.id = h.user_id
        WHERE u.id=?
    """, (user_id,)).fetchone()
    conn.close()
    return dict(row) if row else None
