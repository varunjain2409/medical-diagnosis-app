import os
import base64
import json
from datetime import datetime

# ─── VISUAL SYMPTOM CATEGORIES ────────────────────────────────────────────────
# Maps visible body areas to potential conditions AI should look for

VISUAL_ASSESSMENT_GUIDE = {
    "skin": {
        "conditions": ["Eczema", "Psoriasis", "Ringworm", "Allergic Rash", "Acne", "Chickenpox", "Measles", "Jaundice (skin yellowing)", "Sunburn", "Contact Dermatitis"],
        "what_to_look_for": ["redness", "rash", "swelling", "discoloration", "scaling", "blisters", "lesions", "yellowing", "bruising"]
    },
    "eye": {
        "conditions": ["Conjunctivitis (Pink Eye)", "Jaundice (yellow eyes)", "Allergic Reaction", "Eye Infection", "Stye"],
        "what_to_look_for": ["redness", "yellow tint", "discharge", "swelling around eye", "irritation", "watering"]
    },
    "throat": {
        "conditions": ["Tonsillitis", "Strep Throat", "Pharyngitis", "Oral Thrush"],
        "what_to_look_for": ["redness", "white patches", "swelling", "inflammation"]
    },
    "tongue": {
        "conditions": ["Vitamin B12 Deficiency", "Iron Deficiency", "Oral Thrush", "Dehydration", "Scarlet Fever"],
        "what_to_look_for": ["pale color", "white coating", "red patches", "swelling", "cracking"]
    },
    "face": {
        "conditions": ["Allergic Reaction", "Mumps", "Bell's Palsy", "Rosacea", "Acne", "Cellulitis"],
        "what_to_look_for": ["swelling", "asymmetry", "rash", "redness", "puffiness"]
    },
    "general": {
        "conditions": ["Various skin conditions", "Visible signs of illness"],
        "what_to_look_for": ["unusual marks", "swelling", "discoloration", "visible abnormalities"]
    }
}

# ─── RULE-BASED VISUAL ANALYSIS (Fallback when no API) ────────────────────────

def rule_based_visual_analysis(area, description=""):
    """
    Fallback visual analysis based on area selected and description.
    In production this is replaced by actual AI vision API.
    """
    guide = VISUAL_ASSESSMENT_GUIDE.get(area, VISUAL_ASSESSMENT_GUIDE["general"])
    desc_lower = description.lower()

    # Simple keyword matching for demo
    matched_conditions = []
    confidence_map = {}

    keyword_rules = {
        "red": {"skin": ["Eczema", "Allergic Rash", "Contact Dermatitis"], "eye": ["Conjunctivitis (Pink Eye)"], "throat": ["Tonsillitis", "Pharyngitis"], "face": ["Rosacea", "Allergic Reaction"]},
        "yellow": {"skin": ["Jaundice (skin yellowing)"], "eye": ["Jaundice (yellow eyes)"], "tongue": ["Vitamin B12 Deficiency"]},
        "rash": {"skin": ["Allergic Rash", "Eczema", "Chickenpox", "Measles"], "face": ["Allergic Reaction", "Rosacea"]},
        "swelling": {"face": ["Mumps", "Allergic Reaction", "Cellulitis"], "eye": ["Allergic Reaction", "Stye"], "throat": ["Tonsillitis"]},
        "white": {"throat": ["Tonsillitis", "Oral Thrush"], "tongue": ["Oral Thrush"]},
        "scale": {"skin": ["Psoriasis", "Eczema", "Ringworm"]},
        "blister": {"skin": ["Chickenpox", "Eczema"]},
        "pale": {"tongue": ["Iron Deficiency", "Vitamin B12 Deficiency"]},
        "patch": {"skin": ["Psoriasis", "Ringworm", "Eczema"], "tongue": ["Oral Thrush"]},
        "pus": {"skin": ["Acne"], "eye": ["Conjunctivitis (Pink Eye)", "Stye"]},
    }

    for keyword, area_map in keyword_rules.items():
        if keyword in desc_lower:
            area_conditions = area_map.get(area, [])
            for cond in area_conditions:
                if cond not in matched_conditions:
                    matched_conditions.append(cond)

    # If no keyword match, return top 3 common conditions for that area
    if not matched_conditions:
        matched_conditions = guide["conditions"][:3]

    # Assign mock confidence scores
    results = []
    base_conf = 65
    for i, cond in enumerate(matched_conditions[:3]):
        conf = max(base_conf - (i * 15), 25)
        results.append({"condition": cond, "confidence": conf, "rank": i + 1})

    return {
        "method": "rule_based",
        "area": area,
        "top_conditions": results,
        "what_was_analyzed": guide["what_to_look_for"],
        "disclaimer": "This is a pattern-based preliminary assessment. AI vision analysis requires OpenAI Vision API key."
    }


# ─── OPENAI VISION ANALYSIS ───────────────────────────────────────────────────

def analyze_image_with_ai(image_path, area, description=""):
    """
    Uses OpenAI GPT-4 Vision to analyze uploaded medical image.
    Falls back to rule-based if API key not set.
    """
    api_key = os.getenv("OPENAI_API_KEY", "")

    if not api_key:
        return rule_based_visual_analysis(area, description)

    try:
        import openai
        client = openai.OpenAI(api_key=api_key)

        # Read and encode image as base64
        with open(image_path, "rb") as f:
            image_data = base64.b64encode(f.read()).decode("utf-8")

        ext = image_path.rsplit(".", 1)[-1].lower()
        mime = "image/jpeg" if ext in ["jpg", "jpeg"] else "image/png" if ext == "png" else "image/jpeg"

        guide = VISUAL_ASSESSMENT_GUIDE.get(area, VISUAL_ASSESSMENT_GUIDE["general"])

        prompt = f"""You are a medical AI assistant performing a PRELIMINARY visual assessment of a patient-uploaded image.

Area of concern: {area.upper()}
Patient description: {description if description else "No additional description provided"}
Possible conditions to consider: {', '.join(guide['conditions'])}

Please analyze the image and respond ONLY in this exact JSON format:
{{
  "visible_findings": ["finding 1", "finding 2", "finding 3"],
  "top_conditions": [
    {{"condition": "Most likely condition", "confidence": 70, "reasoning": "brief reason"}},
    {{"condition": "Second possibility", "confidence": 45, "reasoning": "brief reason"}},
    {{"condition": "Third possibility", "confidence": 25, "reasoning": "brief reason"}}
  ],
  "urgency": "low/medium/high",
  "recommendation": "What the patient should do next",
  "disclaimer": "Standard medical disclaimer"
}}

Important: Be conservative. If image quality is poor or condition is unclear, say so. Never make definitive diagnoses."""

        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{image_data}", "detail": "high"}}
                ]
            }],
            max_tokens=800
        )

        raw = response.choices[0].message.content.strip()
        # Clean JSON if wrapped in markdown
        if "```json" in raw:
            raw = raw.split("```json")[1].split("```")[0].strip()
        elif "```" in raw:
            raw = raw.split("```")[1].split("```")[0].strip()

        result = json.loads(raw)
        result["method"] = "gpt4_vision"
        result["area"] = area
        return result

    except json.JSONDecodeError:
        return rule_based_visual_analysis(area, description)
    except Exception as e:
        result = rule_based_visual_analysis(area, description)
        result["api_error"] = str(e)
        return result


# ─── SAVE VISUAL ASSESSMENT TO DB ─────────────────────────────────────────────

def build_visual_report(analysis_result, patient_info, area):
    """Generate a readable report from visual analysis results."""
    now = datetime.now().strftime("%B %d, %Y at %I:%M %p")
    method_label = "GPT-4 Vision AI" if analysis_result.get("method") == "gpt4_vision" else "Pattern-Based Analysis"

    top = analysis_result.get("top_conditions", [])
    findings = analysis_result.get("visible_findings", ["Visual assessment performed"])
    urgency = analysis_result.get("urgency", "medium")
    recommendation = analysis_result.get("recommendation", "Please consult a dermatologist or relevant specialist.")

    urgency_map = {"low": "🟡 LOW", "medium": "🟠 MODERATE", "high": "🔴 HIGH"}
    urgency_str = urgency_map.get(urgency, "🟠 MODERATE")

    report = f"""
╔══════════════════════════════════════════════╗
   VISUAL DISEASE ASSESSMENT REPORT
   Method : {method_label}
   Area   : {area.upper()}
   Date   : {now}
╚══════════════════════════════════════════════╝

PATIENT
───────
Name   : {patient_info.get('full_name', 'N/A')}
Age    : {patient_info.get('age', 'N/A')}
Gender : {patient_info.get('gender', 'N/A')}

VISUAL FINDINGS
───────────────
"""
    for f in findings:
        report += f"  • {f}\n"

    report += f"""
AI ASSESSMENT RESULTS
─────────────────────
"""
    for t in top:
        bar = "█" * int(t.get("confidence", 0) // 10) + "░" * (10 - int(t.get("confidence", 0) // 10))
        reasoning = t.get("reasoning", "")
        report += f"  #{t.get('rank', '')}  {t.get('condition', 'Unknown')}  [{bar}]  {t.get('confidence', 0)}%\n"
        if reasoning:
            report += f"      → {reasoning}\n"

    report += f"""
URGENCY LEVEL
─────────────
{urgency_str}

RECOMMENDATION
──────────────
{recommendation}

─────────────────────────────────────────────
⚠️  DISCLAIMER: This visual assessment is AI-generated and
preliminary in nature. It is NOT a medical diagnosis.
Always consult a qualified healthcare professional for
proper evaluation and treatment.
─────────────────────────────────────────────
"""
    return report.strip()
